package net.minecraft.src;

public enum EnumMovingObjectType {
	TILE,
	ENTITY;
}
