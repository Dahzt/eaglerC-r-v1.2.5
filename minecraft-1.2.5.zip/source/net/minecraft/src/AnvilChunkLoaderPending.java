package net.minecraft.src;

class AnvilChunkLoaderPending {
	public final ChunkCoordIntPair field_48427_a;
	public final NBTTagCompound field_48426_b;

	public AnvilChunkLoaderPending(ChunkCoordIntPair var1, NBTTagCompound var2) {
		this.field_48427_a = var1;
		this.field_48426_b = var2;
	}
}
