package net.minecraft.src;

public class EntityEggInfo {
	public int spawnedID;
	public int primaryColor;
	public int secondaryColor;

	public EntityEggInfo(int var1, int var2, int var3) {
		this.spawnedID = var1;
		this.primaryColor = var2;
		this.secondaryColor = var3;
	}
}
