package argo.jdom;

public class JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
	JsonNodeDoesNotMatchJsonNodeSelectorException(String var1) {
		super(var1);
	}
}
