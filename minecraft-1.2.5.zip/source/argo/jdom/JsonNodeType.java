package argo.jdom;

public enum JsonNodeType {
	OBJECT,
	ARRAY,
	STRING,
	NUMBER,
	TRUE,
	FALSE,
	NULL;
}
