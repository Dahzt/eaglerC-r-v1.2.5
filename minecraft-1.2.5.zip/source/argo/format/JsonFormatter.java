package argo.format;

import argo.jdom.JsonRootNode;

public interface JsonFormatter {
	String format(JsonRootNode var1);
}
